package com.in28minutes.jpa.hibernate.demo.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.in28minutes.jpa.hibernate.demo.entity.Course;
import com.in28minutes.jpa.hibernate.demo.entity.Faculty;


@Component
@Transactional
public class FacultyRepo {

	@Autowired
	EntityManager em;
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	public void save(Faculty f) {
		if(f.getFacultyId() ==0) {
		this.em.persist(f);
		}
		else {
			this.em.merge(f);
		}
	}
	
	public Faculty findById(int id) {
		Faculty f= this.em.find(Faculty.class, id);
		logger.info(f.toString());
		return f;
	}
	public List<Course> getAllCourses(int id) {
		Faculty f= this.em.find(Faculty.class, id);
		logger.info(f.toString());
		return f.getFacultyCourse();
	}
	
	public void updateTotalExp(int id, int exp) {
		Faculty f= this.em.find(Faculty.class, id);
		logger.info(f.toString());
		f.setTotalExp(exp);
		logger.info("After updating Exp"+f.getTotalExp());

	}
	
	 public List<Faculty> getAllFaculties() {
		 	// JPQL // Java persistant query language // object base 
		  List<Faculty> f = em.createQuery("select f from Faculty f",Faculty.class).getResultList(); 
		  logger.info("retrevied result"+f);
		  return f;
	  }
}
