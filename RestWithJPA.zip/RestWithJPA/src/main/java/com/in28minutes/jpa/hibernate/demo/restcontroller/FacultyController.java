package com.in28minutes.jpa.hibernate.demo.restcontroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.in28minutes.jpa.hibernate.demo.dao.FacultyDAO;
import com.in28minutes.jpa.hibernate.demo.entity.Course;
import com.in28minutes.jpa.hibernate.demo.entity.Faculty;

import java.util.*;

@RestController
@RequestMapping("/faculties")
public class FacultyController {
    @Autowired
    private FacultyDAO facultyService;

    @GetMapping("getall/")
    public List<Faculty> getAllFaculties() {
        return facultyService.getAllFaculties();
    }

    @GetMapping("getall/{id}")
    public Faculty getFacultyById(@PathVariable int id) {
        return facultyService.getFacultyById(id);
    }
    
    @PutMapping("addFaculty")
    public boolean addFaculty(Faculty f) {
    	return facultyService.addFaculty(f);
    }
    
    @GetMapping("getfacultycourse/{id}")
    public List<Course> getAllCourses(@PathVariable int id){
    	return facultyService.getAllCourses(id);
    }

}