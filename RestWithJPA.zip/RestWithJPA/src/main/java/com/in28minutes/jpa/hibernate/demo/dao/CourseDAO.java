package com.in28minutes.jpa.hibernate.demo.dao;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.in28minutes.jpa.hibernate.demo.entity.Course;
import com.in28minutes.jpa.hibernate.demo.repository.CourseRepo;

import java.util.List;

@Component
public class CourseDAO {
    @Autowired
    private CourseRepo courseRepository;

    public List<Course> getAllCourses() {
        return courseRepository.retrieveCourses();
    }

    public Course getCourseById(int id) {
        return courseRepository.findById(id);
    }

   }
