package com.in28minutes.jpa.hibernate.demo.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.in28minutes.jpa.hibernate.demo.entity.Course;
import com.in28minutes.jpa.hibernate.demo.entity.Faculty;


@Component
@Transactional
public class CourseRepo {

	@Autowired
	EntityManager em;
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	public void save(Course c) {
		if(c.getCourseId()==0) {
		this.em.persist(c);
		}
		else {
			this.em.merge(c);
		}
	}
	
	public Course findById(int id) {
		Course c= this.em.find(Course.class, id);
		logger.info(c.toString());
		return c;
	}
	
	public void updateCourseName(int id, String name) {
		Course c= this.em.find(Course.class, id);
		logger.info(c.toString());
		c.setCourseName(name);

	}
	
	 public List<Course> retrieveCourses() {
		 	// JPQL // Java persistant query language // object base 
		  List<Course> c = em.createQuery("select c from Course c",Course.class).getResultList(); 
		  logger.info("retrevied result"+c);
		  return c;
	  }

	
}
