package com.in28minutes.jpa.hibernate.demo.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.in28minutes.jpa.hibernate.demo.entity.Course;
import com.in28minutes.jpa.hibernate.demo.entity.Faculty;
import com.in28minutes.jpa.hibernate.demo.repository.FacultyRepo;

import java.util.*;

@Component
public class FacultyDAO {
    @Autowired
    private FacultyRepo facultyRepository;

    public List<Faculty> getAllFaculties() {
        return facultyRepository.getAllFaculties();
    }

    public Faculty getFacultyById(int id) {
        return facultyRepository.findById(id);
    }
    
    public boolean addFaculty(Faculty f){
    	facultyRepository.save(f);
    	return true;
    }
    
    public List<Course> getAllCourses(int id){
    	return facultyRepository.getAllCourses(id);
    }
  
}
