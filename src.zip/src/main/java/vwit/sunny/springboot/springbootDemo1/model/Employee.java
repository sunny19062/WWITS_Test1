package vwit.sunny.springboot.springbootDemo1.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

//every class in java extends Object
@Component
public class Employee {
	
    private int empId;
	private String empName;
	private double empSalary;
//    int deptno;
	@Autowired
	Dept dept;
	
	protected String proj;
	
	public Employee()
	{
		System.out.println("0 arg Employee constructor called..");
	}
	
	
	public Employee(@Value("employee.empId") int empId,
			@Value("employee.empName") String empName,
			@Value("employee.empSalary") double empSalary,Dept dept)
	{
		
		this.empId = empId;
		this.empName = empName;
		this.empSalary = empSalary;
		this.dept = dept;
		
	}
//	public Employee(int empId,String empName,double empSalary,Dept dept)
//	{
//		
//		this.empId = empId;
//		this.empName = empName;
//		this.empSalary = empSalary;
//		this.dept = dept;
//		
//	}
	
	//overloaded copy constructor
//	public Employee(Employee ob)
//	{
//		this.empId = ob.empId;
//		this.empName = ob.empName;
//		this.empSalary = ob.empSalary;
//		this.deptno = ob.deptno;
//	}
	
	
	//setter and getter methods for all private properties
	
	
	//2000 loc
    public double computeAnnualSalary()
	{
		
		return this.empSalary*12; //jump back to 1001
	}
	
	public Dept getDept() {
		return dept;
	}

	public void setDept(Dept dept) {
		this.dept = dept;
	}

	//function overloading
	//compile-time polymorphism //static polymorphism
	//early binding
	public double computeAnnualSalary(long bonus)
	{
		
		System.out.println("inside computeAnnualSalary(long)");
		return this.empSalary*12 + bonus;
	}
	
	public double computeAnnualSalary(int incentive)
	{
		
		System.out.println("inside computeAnnualSalary(int");
		
		return this.empSalary*12 + incentive;
	}
	
	
	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public double getEmpSalary() {
		return empSalary;
	}

	public void setEmpSalary(double empSalary) {
		
		if(empSalary>0)
		{
		  this.empSalary = empSalary;
		}
		else
		{
			System.out.println("you are trying to set salary value as:"+empSalary+",but Salary can't be -ve");
		}
	}

//	public int getDeptno() {
//		return deptno;
//	}

//	public void setDeptno(int deptno) {
//		this.deptno = deptno;
//	}

	public int getEmpId() {
		return empId;
	}

	
//	  @Override 
//	  public int hashCode()
//	  {
//		  System.out.println("Employee's hashCode method called...");   
//		  return this.deptno;
//	  }
	
	  @Override public boolean equals(Object obj)  //Object obj = e
	  {
	       System.out.println("Employee's equals method called..."); 
	       return   this.empId==((Employee)obj).empId; 
	   }
	
	 
	
	  @Override 
	  public String toString() {
	  
	  System.out.println("toString of Employee called..."); 
	  
	  return
	  "emp details:empid:"+this.empId +", empname:"+this.empName
	  +", empsalary:"+this.empSalary +", empdeptno:"+this.dept; }
	 
	
	

}
