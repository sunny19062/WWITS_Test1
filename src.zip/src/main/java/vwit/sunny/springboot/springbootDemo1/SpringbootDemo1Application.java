package vwit.sunny.springboot.springbootDemo1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;

import vwit.sunny.springboot.springbootDemo1.Config.EmployeeConfig;
import vwit.sunny.springboot.springbootDemo1.model.Dept;
import vwit.sunny.springboot.springbootDemo1.model.Employee;


//@SpringConfiguration,@EnableAutoConfiguration,@ComponentScan
@ComponentScan(basePackages = { "restcontroller","vwit.sunny.springboot.springbootDemo1"})
@SpringBootApplication
public class SpringbootDemo1Application //implements CommandLineRunner 
{

//	@Autowired
//	EmployeeConfig empConfig;
	public static void main(String[] args) {
		ConfigurableApplicationContext ctx = SpringApplication.run(SpringbootDemo1Application.class, args);
		Employee emp = (Employee) ctx.getBean("employee");
		System.out.println(emp.computeAnnualSalary());
		System.out.println(emp.getEmpName());
		
		Dept dept=emp.getDept();
		System.out.println(dept.getDeptid());
		System.out.println(ctx.containsBeanDefinition("dept"));
		System.out.println(ctx.containsBeanDefinition("employee"));
		
		Dept ndept = (Dept) ctx.getBean("dept");
		System.out.println(ndept.getDeptName());
		System.out.println(ndept);
	}

//	@Override
//	public void run(String... args) throws Exception {
//		// TODO Auto-generated method stub
//		System.out.println("Run implemented: "+args);
////		System.out.println(empConfig);
////		System.out.println(empConfig.getEmpName());
//		
//	}

}
