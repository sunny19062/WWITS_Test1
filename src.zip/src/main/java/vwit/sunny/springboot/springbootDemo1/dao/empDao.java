package vwit.sunny.springboot.springbootDemo1.dao;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import vwit.sunny.springboot.springbootDemo1.Config.EmployeeConfig;
import vwit.sunny.springboot.springbootDemo1.model.Employee;


@Component
public class empDao {
	
	EmployeeConfig empConfig;
	private List<Employee> lst;
	
//	@Autowired // Optional in the case of constructer because it autometically undertand it.
	public empDao(EmployeeConfig empConfig) {
		this.empConfig=empConfig;
		this.lst = new ArrayList<Employee>();
//		lst.add(new Employee(empConfig.getEmpId(),empConfig.getEmpName(),empConfig.getEmpSalary(),empConfig.getEmpDept()));
//		lst.add(new Employee(1,"A",1000,10));
//		lst.add(new Employee(2,"B",1000,10));
//		lst.add(new Employee(3,"C",1000,10));
	}
	
	public Employee findEmp(int empId) {
		
		Employee emp =lst.stream().filter(e->e.getEmpId()==empId).findFirst().orElse(null);
		return emp;
	}
	
//	public Employee findEmp(int empId, int empDept) {
//		
//		Employee emp =lst.stream().filter(e->e.getEmpId()==empId && e.getDeptno()==empDept).findFirst().orElse(null);
//		return emp;
//	}
	
//	public Employee findEmp(int empId, String empName) {
//		System.out.println("Dao: EmpName: "+empName+"empId: "+empId);
//		Employee emp =lst.stream().filter(e->e.getEmpId()==empId && e.getEmpName().equals(empName.strip())).findFirst().orElse(new Employee(0,"Demo",0,0));
//		return emp;
//	}
	
	public List<Employee> getAllEmp(){
		return this.lst;
	}
	public List<Employee> addEmp(Employee e){
		lst.add(e);
		return this.lst;
	}
	
}
