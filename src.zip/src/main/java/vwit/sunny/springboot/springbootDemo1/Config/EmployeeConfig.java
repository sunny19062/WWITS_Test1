package vwit.sunny.springboot.springbootDemo1.Config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties("employee")
@Profile("dev")
public class EmployeeConfig {
	private int empId;
	private String empName;
	private double empSalary;
	private int empDept;
	
	public EmployeeConfig() {
		super();
	}
		
	public EmployeeConfig(int empId, String empName, double empSalary, int empDept) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSalary = empSalary;
		this.empDept = empDept;
	}
	
	
	public double getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(double empSalary) {
		this.empSalary = empSalary;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public int getEmpDept() {
		return empDept;
	}
	public void setEmpDept(int empDept) {
		this.empDept = empDept;
	}
	public int getEmpId() {
		return empId;
	}
	public String getEmpName() {
		return empName;
	}
	@Override
	public String toString() {
		return "EmployeeConfig [empId=" + empId + ", empName=" + empName + ", empSalary=" + empSalary + ", empDept="
				+ empDept + "]";
	}
	
	

}
