package vwit.sunny.springboot.springbootDemo1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootDemo1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
