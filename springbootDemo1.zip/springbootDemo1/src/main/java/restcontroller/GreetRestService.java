package restcontroller;


import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import vwit.sunny.springboot.springbootDemo1.dao.empDao;
import vwit.sunny.springboot.springbootDemo1.model.Employee;

@RestController
public class GreetRestService {
	
		@Autowired
		empDao empdao;
		public static Logger logger = LoggerFactory.getLogger(GreetRestService.class); 
		
		@GetMapping("hello")
		public String sayHello() {
			logger.debug("Debug hello() called");
			return "Greet Everyone";
		
		}
		@GetMapping("emp/{empId}")
		public Employee getEmp(@PathVariable int empId) {
			
			logger.debug("EmpId"+empId);
			Employee x= empdao.findEmp(empId);
			logger.debug("Found Employee"+x);
			return x;
		}
		
		@GetMapping("allemp")
		public List<Employee> getEmps(){
			return empdao.getAllEmp();
		}
		
		@PostMapping("emp")
		public List<Employee> postEmp(@RequestBody Employee e) {
			return empdao.addEmp(e);
		}
}
