package vwit.sunny.springboot.springbootDemo1.dao;

import java.util.*;


import org.springframework.stereotype.Service;


import vwit.sunny.springboot.springbootDemo1.model.Employee;


@Service
public class empDao {

	private List<Employee> lst;
	
	public empDao() {
		this.lst = new ArrayList<Employee>();
		lst.add(new Employee(1,"A",1000,10));
		lst.add(new Employee(2,"B",1000,10));
		lst.add(new Employee(3,"C",1000,10));
	}
	
	public Employee findEmp(int empId) {
		
		Employee emp =lst.stream().filter(e->e.getEmpId()==empId).findFirst().orElse(null);
		return emp;
	}
	
	public List<Employee> getAllEmp(){
		return this.lst;
	}
	public List<Employee> addEmp(Employee e){
		lst.add(e);
		return this.lst;
	}
	
}
