package spring.web.vwit.MVCDemo1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MvcDemo1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
