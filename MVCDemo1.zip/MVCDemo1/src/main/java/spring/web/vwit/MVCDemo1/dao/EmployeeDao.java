package spring.web.vwit.MVCDemo1.dao;


import java.util.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import spring.web.vwit.MVCDemo1.exception.EmployeeNotFoundException;
import spring.web.vwit.MVCDemo1.model.Employee;
import spring.web.vwit.MVCDemo1.repo.EmployeeRepo;

@Service
public class EmployeeDao {

	@Autowired
	EmployeeRepo er;
	Logger logger =LoggerFactory.getLogger(EmployeeDao.class);

	public Employee saveEmp(Employee e){
		e= er.save(e);
		logger.debug("Fetched Employee: {}",e);
		return e;
	}
	
	public Employee fetchEmp(int empId) {
		Optional<Employee> opemp= er.findById(empId);
		if (opemp.isPresent()) {
			return opemp.get();
		}
		else {
			throw new EmployeeNotFoundException("Employee with empId: "+empId+" Not Found");
		}
	}
	
	public List<Employee> getAllEmployee() {
		return er.findAll();
	}
   

   
}
