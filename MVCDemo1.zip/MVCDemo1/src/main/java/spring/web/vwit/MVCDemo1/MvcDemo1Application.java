package spring.web.vwit.MVCDemo1;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import spring.web.vwit.MVCDemo1.dao.EmployeeDao;
import spring.web.vwit.MVCDemo1.model.Employee;

@SpringBootApplication
public class MvcDemo1Application implements CommandLineRunner {

	@Autowired
	EmployeeDao ed;
	public static void main(String[] args)  {
		SpringApplication.run(MvcDemo1Application.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		Employee e= new Employee(1,"Peter",5000.0,LocalDate.now(),10);
		ed.saveEmp(e);
		
		e= new Employee(2,"Bruce",10000.0,LocalDate.of(2022,02,10),15);
		ed.saveEmp(e);
		
		
		
	}

}
