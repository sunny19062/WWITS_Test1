package spring.web.vwit.MVCDemo1.exception;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;



@ControllerAdvice
public class ResponseEntityExceptionHandlerAdvice  extends ResponseEntityExceptionHandler{
	
	 @ExceptionHandler(EmployeeNotFoundException.class)
	    public ResponseEntity<Object> handleEmployeeNotFoundException(
	            EmployeeNotFoundException ex, WebRequest request) {

	        Map<String, Object> body = new LinkedHashMap<>();
	        body.put("timestamp", LocalDateTime.now());
	        body.put("message", ex.getMessage());

	        return new ResponseEntity<>(body, HttpStatus.NOT_FOUND);
	    }
	 @ExceptionHandler(jakarta.validation.ConstraintViolationException.class)
		ResponseEntity<Object> handleRuntimeException(jakarta.validation.ConstraintViolationException e)
		{
			  Map<String, Object> body = new LinkedHashMap<>();
		        body.put("timestamp", LocalDateTime.now());
		        body.put("message","bean validation exception:"+ e.getMessage());
	 
		        return new ResponseEntity<>(body, HttpStatus.BAD_REQUEST);
		}

	 
	 @ExceptionHandler(RuntimeException.class)
	    public ResponseEntity<Object> handleRuntimeException(
	    		RuntimeException ex, WebRequest request) {

	        Map<String, Object> body = new LinkedHashMap<>();
	        body.put("timestamp", LocalDateTime.now());
	        body.put("message", ex.getMessage());

	        return new ResponseEntity<>(body, HttpStatus.NOT_FOUND);
	    }
 
	 
}
