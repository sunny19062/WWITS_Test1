package spring.web.vwit.MVCDemo1.model;

import java.time.LocalDate;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;


@Entity
//@Table(name="Employee")
public class Employee {
	
	@Id
	//@GeneratedValue
	@NotNull(message="EmpTd can not be null.")
	private int empId;
	
	@NotNull
	@NotBlank(message = "Name is mandatory")
	@Size(min=3,message="Name length should be greater then 3.")
	private String empName;
	
	@NotNull(message="EmpSalary can not be null.")
	private double empSalary;
	
	@NotNull(message="EmpJoinDate can not be null.")
	private LocalDate empJoinDate;
	
	@NotNull(message="EmpDept can not be null.")
	private int empDept;
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Employee( String empName, double empSalary, LocalDate empJoinDate, int empDept) {
		super();
		
		this.empName = empName;
		this.empSalary = empSalary;
		this.empJoinDate = empJoinDate;
		this.empDept = empDept;
	}
	
	public Employee(int empId, String empName, double empSalary, LocalDate empJoinDate, int empDept) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSalary = empSalary;
		this.empJoinDate = empJoinDate;
		this.empDept = empDept;
	}
	


	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(double empSalary) {
		this.empSalary = empSalary;
	}
	public int getEmpDept() {
		return empDept;
	}
	public void setEmpDept(int empDept) {
		this.empDept = empDept;
	}
	
	
	
	public LocalDate getEmpJoinDate() {
		return empJoinDate;
	}

	public void setEmpJoinDate(LocalDate empJoinDate) {
		this.empJoinDate = empJoinDate;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSalary=" + empSalary + ", empJoinDate="
				+ empJoinDate + ", empDept=" + empDept + "]";
	}

	

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		return empId == other.empId;
	}


	
	
	
	
}
