package spring.web.vwit.MVCDemo1.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import jakarta.validation.Valid;
import spring.web.vwit.MVCDemo1.dao.EmployeeDao;
import spring.web.vwit.MVCDemo1.model.Employee;

@RequestMapping("/web")
@Controller
public class WebController {
	
	@Autowired
	EmployeeDao ed;
	
	@GetMapping("/emp/{empId}")
	public String getEmployee(@PathVariable int empId,ModelMap map) {
		Employee e =ed.fetchEmp(empId);
		map.addAttribute("Empid", empId);
		map.addAttribute("emp", e);
		return "employee";
		
	}
	
	@GetMapping("/")
	public String getEmpform(Model m) {
		Employee e = new Employee();
		m.addAttribute("employee", e);
		return "empform";
	}
	
	@PostMapping("/empp")
	public String saveEmpForm(@ModelAttribute("employee") @Valid Employee e,BindingResult bindingResult,ModelMap map) {
		if (bindingResult.hasErrors()) {
//			logger.info("employee validation failed:Returning back to empform.jsp page");
			return "empform";
		}
		else {
		map.addAttribute("emp", e);
		ed.saveEmp(e);
		return "saveform";
		}
	}
}
