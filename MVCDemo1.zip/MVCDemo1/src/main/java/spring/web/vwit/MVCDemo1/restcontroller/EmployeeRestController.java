package spring.web.vwit.MVCDemo1.restcontroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import spring.web.vwit.MVCDemo1.dao.EmployeeDao;
import spring.web.vwit.MVCDemo1.model.Employee;


import java.util.List;

@RestController
@RequestMapping("/employees")
public class EmployeeRestController {
	@Autowired
	EmployeeDao ed;
	
	@GetMapping("/emp/{empid}")
	public Employee getEmployee(@PathVariable int empId) {
		return ed.fetchEmp(empId);
	}
    
	@GetMapping("/emps")
	public List<Employee> getAllEmployee(){
		return ed.getAllEmployee();
	}
	
	@PostMapping("/emp")
	public Employee addEmployee(@RequestBody Employee e) {
		return ed.saveEmp(e);
	}
}
